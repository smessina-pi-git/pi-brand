const { chromium } = require('playwright');
const fs=require('fs');
(async()=>{
  const [,, jsonPath, outDir, framesArg] = process.argv;
  fs.mkdirSync(outDir,{recursive:true});
  const b = await chromium.launch({executablePath:'/opt/pw-browsers/chromium'}).catch(()=>chromium.launch());
  const data=fs.readFileSync(jsonPath,'utf8'), meta=JSON.parse(data);
  const p = await b.newPage({viewport:{width:meta.w,height:meta.h}});
  const lottie=fs.readFileSync(require.resolve('lottie-web/build/player/lottie.min.js'),'utf8');
  await p.setContent(`<html><body style="margin:0"><div id=a style="width:${meta.w}px;height:${meta.h}px"></div></body></html>`);
  await p.addScriptTag({content:lottie});
  await p.evaluate(d=>{window.anim=lottie.loadAnimation({container:document.getElementById('a'),renderer:'svg',loop:false,autoplay:false,animationData:JSON.parse(d)});},data);
  await p.waitForTimeout(1500);
  const frames=framesArg.split(',').map(Number);
  for(const f of frames){await p.evaluate(f=>anim.goToAndStop(f,true),f);await p.waitForTimeout(100);await p.screenshot({path:`${outDir}/f${String(f).padStart(3,'0')}.png`});}
  await b.close();
})();
