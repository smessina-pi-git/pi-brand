"""Build Lottie glyph ("chars") entries for Roboto Regular/Bold/Italic.
Reuses the original After Effects glyphs where present, generates the rest from the font files."""
import json
from fontTools.ttLib import TTFont
from fontTools.pens.basePen import BasePen

SRC = json.load(open('/home/claude/src.json'))
FONTS = {
    'Regular': 'fonts/package/fonts/roboto/Roboto-Regular.woff',
    'Bold': 'fonts/package/fonts/roboto/Roboto-Bold.woff',
    'Italic': 'fonts/package/fonts/roboto/Roboto-RegularItalic.woff',
}
CHARSET = [chr(c) for c in range(32, 127)] + list("’‘“”–—…•·©®™°×÷éèêëáàâäãåçíìîïñóòôöõúùûüýÉÈÁÀÇÑÓÖÜ€£¢¥§¶")


class LottiePen(BasePen):
    def __init__(self, glyphSet, scale):
        super().__init__(glyphSet)
        self.s = scale
        self.contours = []
        self.cur = None

    def p(self, pt):
        return [round(pt[0] * self.s, 3), round(-pt[1] * self.s, 3)]

    def _moveTo(self, pt):
        self.cur = {'v': [self.p(pt)], 'i': [[0, 0]], 'o': [[0, 0]]}

    def _lineTo(self, pt):
        c = self.cur
        c['v'].append(self.p(pt)); c['i'].append([0, 0]); c['o'].append([0, 0])

    def _curveToOne(self, p1, p2, p3):
        c = self.cur
        a = c['v'][-1]
        b1, b2, e = self.p(p1), self.p(p2), self.p(p3)
        c['o'][-1] = [round(b1[0] - a[0], 3), round(b1[1] - a[1], 3)]
        c['v'].append(e)
        c['i'].append([round(b2[0] - e[0], 3), round(b2[1] - e[1], 3)])
        c['o'].append([0, 0])

    def _closePath(self):
        c = self.cur
        if len(c['v']) > 1 and c['v'][-1] == c['v'][0]:
            # merge closing duplicate vertex
            c['i'][0] = c['i'][-1]
            c['v'].pop(); c['i'].pop(); c['o'].pop()
        self.contours.append(c)
        self.cur = None

    _endPath = _closePath


def glyph_entry(ch, style, font):
    upm = font['head'].unitsPerEm
    gname = font.getBestCmap().get(ord(ch))
    if gname is None:
        return None
    gs = font.getGlyphSet()
    pen = LottiePen(gs, 100 / upm)
    gs[gname].draw(pen)
    w = round(font['hmtx'][gname][0] * 100 / upm, 2)
    entry = {'ch': ch, 'size': 40, 'style': style, 'w': w, 'fFamily': 'Roboto'}
    if not pen.contours:
        entry['data'] = {}
        return entry
    its = []
    for n, c in enumerate(pen.contours):
        its.append({'ind': n, 'ty': 'sh', 'ix': n + 1,
                    'ks': {'a': 0, 'k': {'i': c['i'], 'o': c['o'], 'v': c['v'], 'c': True}, 'ix': 2},
                    'nm': ch, 'mn': 'ADBE Vector Shape - Group', 'hd': False})
    entry['data'] = {'shapes': [{'ty': 'gr', 'it': its, 'nm': ch, 'np': len(its) + 3, 'cix': 2, 'bm': 0,
                                 'ix': 1, 'mn': 'ADBE Vector Group', 'hd': False}]}
    return entry


orig = {(c['ch'], c['style']): c for c in SRC['chars']}
out = {}
for style, path in FONTS.items():
    f = TTFont(path)
    lst = []
    for ch in CHARSET:
        if (ch, style) in orig:
            lst.append(orig[(ch, style)])
        else:
            e = glyph_entry(ch, style, f)
            if e: lst.append(e)
    out[style] = lst
    print(style, len(lst))
json.dump(out, open('glyphs.json', 'w'), separators=(',', ':'), ensure_ascii=False)

# test: generated vs original for chars in the source
test = []
for style, path in FONTS.items():
    f = TTFont(path)
    for (ch, st), c in orig.items():
        if st == style:
            test.append(glyph_entry(ch, style, f))
json.dump(test, open('glyphs_test.json', 'w'), separators=(',', ':'), ensure_ascii=False)
