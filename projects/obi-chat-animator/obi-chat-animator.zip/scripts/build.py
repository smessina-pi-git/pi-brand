"""Assemble dist.html from src/page.template.html + src/*.js + vendor/ + assets/."""
import pathlib
root = pathlib.Path(__file__).resolve().parent.parent
esc = lambda s: s.replace('</', '<\\/')
read = lambda p: (root / p).read_text()
t = read('src/page.template.html')
for key, path, escape in [('__PARTS__', 'assets/parts.json', True), ('__GLYPHS__', 'assets/glyphs.json', True),
                          ('__GIFENC__', 'vendor/gifenc.js', True), ('__GEN__', 'src/generator.js', True), ('__APP__', 'src/app.js', True)]:
    assert key in t, key
    t = t.replace(key, esc(read(path)) if escape else read(path))
(root / 'dist.html').write_text(t)
print('wrote dist.html', len(t.encode()), 'bytes')
