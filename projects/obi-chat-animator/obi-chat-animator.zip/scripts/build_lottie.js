// node scripts/build_lottie.js transcript.txt out.json   — build a Lottie from a labelled transcript without the UI
// env: ASKER=Name  SIZE=square|wide|tall
const fs = require('fs'), path = require('path');
const G = require('../src/generator.js');
const root = path.join(__dirname, '..');
const parts = JSON.parse(fs.readFileSync(path.join(root, 'assets/parts.json')));
const glyphs = JSON.parse(fs.readFileSync(path.join(root, 'assets/glyphs.json')));
const [,, inFile, outFile] = process.argv;
const turns = G.parseTurns(fs.readFileSync(inFile, 'utf8'));
const r = G.build(parts, glyphs, { turns, asker: process.env.ASKER || 'Alex', size: process.env.SIZE || 'square' });
console.log(r.warnings, r.info);
fs.writeFileSync(outFile, JSON.stringify(r.json));
