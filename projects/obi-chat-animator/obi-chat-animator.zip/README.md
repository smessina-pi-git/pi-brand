# Obi Chat Animator

Turns User/Obi lines into an animation in the Obi input-box style. It exports in three sizes (Square 1:1, 16:9, 9:16) as an MP4, an email GIF with a fallback image, a PNG still, or Lottie JSON. Everything renders in the browser.

## Layout

- `src/generator.js` builds the Lottie JSON from scratch. `ObiChat.build(parts, glyphs, {turns, asker, avatar, smartQuotes, name, size})` returns `{json, warnings, info, stills, poster, background}`. `size` is `square` (1080×1080), `wide` (1920×1080) or `tall` (1080×1920). `parseTurns(text)` reads a `User:` / `Obi:` transcript. It works in the browser (as the global `ObiChat`) and in Node.
- `src/app.js` is the builder UI: line editor, live preview, size and format selectors, and the four exporters.
- `src/page.template.html` holds the page markup and styles (Brand Canvas look). `scripts/build.py` fills its `__PARTS__`, `__GLYPHS__`, `__GIFENC__`, `__GEN__` and `__APP__` placeholders.
- `vendor/gifenc.js` is gifenc 1.0.3 (MIT), converted to a plain script. It's inlined so GIF export doesn't depend on a CDN.
- `assets/glyphs.json` holds Roboto Regular and Bold outlines in Lottie `chars` format, so the animation needs no font files. `scripts/make_glyphs.py` regenerates them, but it needs the original Roboto font files and `src.json`, which aren't in this folder.
- `assets/parts.json` holds the PI logo shapes, the send button and the default avatar.
- `dist.html` is the assembled single-file page. Open it in Chrome, or publish it.

## Build and run

```
python3 scripts/build.py                                  # -> dist.html
python3 -m http.server 8765                               # then open http://localhost:8765/dist.html
SIZE=wide node scripts/build_lottie.js chat.txt out.json  # Lottie from a transcript, no UI
```

`samples/chat.txt` shows the transcript format. `@Name` or `@[First Last]` marks a name to bold, and the @ isn't shown.

## Exports

| Format | Output |
|---|---|
| MP4 | Full size (1080×1080, 1920×1080 or 1080×1920) at 24 fps. Uses WebCodecs: H.264 in Chrome and Edge, with a VP9 fallback elsewhere. |
| GIF | Email size (600×600, 600×338 or 450×800). It's kept under 1 MB by stepping down from 12 fps to 8 fps, then shrinking to 84% and then 70% of that size. Encoding uses one shared palette, sends unchanged pixels as transparent, merges repeated frames, and applies an ordered dither to stop the background glows banding. The GIF starts on the opening box rather than a blank frame. It ships in a ZIP with a fallback JPG of the finished conversation at 2× for Outlook desktop, which shows only a GIF's first frame. |
| PNG | One still per exchange at full size. More than one still is saved as a ZIP. |
| Lottie | JSON at the selected size. |

Saving: when the page is published as a Claude artifact with the `downloads` capability, it uses the viewer's save prompt. Anywhere else it's an ordinary browser download, plus a "save it again" link.

## Animation (24 fps)

The conversation is auto-fitted to each frame size: never scaled down, and scaled up by at most 1.4×.

| Beat | Timing |
|---|---|
| Opening | The box springs in with the header and its sparkle. Placeholder and blinking caret for 20 frames. |
| Typing | 1.5 characters per frame. |
| Send | 4-frame press with a ripple. |
| Box → bubble | 12-frame morph. |
| Avatar and Obi logo | Spring pops. |
| Thinking dots | 18 frames. |
| Reply | Words rise and fade in, 2 frames per word. |
| End | Hold for 66 frames (36 between exchanges), then fade. |

Later exchanges rise in while the previous one slides up and out. The background glows are static on purpose, so loops are seamless and GIFs stay small. All timing lives in `buildTurn()` in `src/generator.js`.

## Rendering checks

`node scripts/render_frames.js out.json frames 0,40,120` renders chosen frames to PNG. It needs `npm i playwright lottie-web`.
