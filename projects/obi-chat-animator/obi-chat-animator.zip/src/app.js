/* Obi Chat Animator — builder UI, preview and exports (MP4, email GIF + fallback, PNG, Lottie). */
(function () {
  'use strict';
  var PARTS = JSON.parse(document.getElementById('parts-data').textContent);
  var GLYPHS = JSON.parse(document.getElementById('glyph-data').textContent);
  var FPS = 24;
  var DEFAULT_LINES = [
    { role: 'user', text: "@Alex and @Jordan don't work well together. Help!" },
    { role: 'obi', text: 'The friction is a communication mismatch: Alex moves fast and verbally, Jordan needs space to process, and both dig in when they disagree.' }
  ];
  var SIZE_TAG = { square: '1x1', wide: '16x9', tall: '9x16' };
  // email GIF canvas per size: 600px is the standard email body width
  var GIF_DIMS = { square: [600, 600], wide: [600, 338], tall: [450, 800] };
  var GIF_BUDGET = 1024 * 1024;   // keep email GIFs at or under 1 MB
  var FORMAT_LABEL = { mp4: 'MP4', gif: 'GIF + fallback', png: 'PNG', json: 'Lottie JSON' };

  var $ = function (id) { return document.getElementById(id); };
  var linesEl = $('lines'), fname = $('fname'), smart = $('smart'), asker = $('asker'), bw = $('bw');
  var lines, avatarRaw = null, avatar = null, anim = null, current = null, playing = true, fnameTouched = false, busy = null;

  function store(k, v) { try { localStorage.setItem(k, v); } catch (e) {} }
  function load(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  try { lines = JSON.parse(load('obi3-lines') || 'null'); } catch (e) { lines = null; }
  if (!Array.isArray(lines) || !lines.length) lines = JSON.parse(JSON.stringify(DEFAULT_LINES));
  asker.value = load('obi2-asker') || 'Alex';
  var savedName = load('obi2-fname'); if (savedName) { fname.value = savedName; fnameTouched = true; }
  $('avatarImg').src = PARTS.avatar;
  function radio(name) { var el = document.querySelector('input[name=' + name + ']:checked'); return el ? el.value : null; }
  function setRadio(name, v) { var el = document.querySelector('input[name=' + name + '][value="' + v + '"]'); if (el) el.checked = true; }
  setRadio('size', load('obi4-size') || 'square');
  setRadio('format', load('obi4-format') || 'mp4');

  // ---------- lines ----------
  function nextRole() { return lines.length && lines[lines.length - 1].role === 'user' ? 'obi' : 'user'; }
  function renderLines(focusIdx) {
    linesEl.innerHTML = '';
    lines.forEach(function (ln, i) {
      var li = document.createElement('li'); li.className = 'msg ' + ln.role;
      var head = document.createElement('div'); head.className = 'msg-head';
      var who = document.createElement('span'); who.className = 'who'; who.innerHTML = '<i></i>'; who.appendChild(document.createTextNode(ln.role === 'user' ? 'User' : 'Obi'));
      var x = document.createElement('button'); x.type = 'button'; x.className = 'textbtn'; x.textContent = 'Remove';
      x.setAttribute('aria-label', 'Remove ' + (ln.role === 'user' ? 'User' : 'Obi') + ' line ' + (i + 1));
      x.disabled = lines.length <= 1;
      x.addEventListener('click', function () { lines.splice(i, 1); renderLines(); changed(); });
      head.appendChild(who); head.appendChild(x); li.appendChild(head);
      var ta = document.createElement('textarea'); ta.id = 'line-' + i; ta.value = ln.text || '';
      ta.rows = ln.role === 'user' ? 2 : 3;
      ta.setAttribute('aria-label', (ln.role === 'user' ? 'User message' : 'Obi reply') + ' ' + (i + 1));
      ta.placeholder = ln.role === 'user' ? 'What the user types' : 'What Obi replies';
      ta.addEventListener('input', function () { ln.text = ta.value; changed(); });
      li.appendChild(ta); linesEl.appendChild(li);
    });
    $('addLine').textContent = '+ Add ' + (nextRole() === 'user' ? 'User' : 'Obi') + ' line';
    if (focusIdx != null) { var t = $('line-' + focusIdx); if (t) t.focus(); }
  }
  $('addLine').addEventListener('click', function () { lines.push({ role: nextRole(), text: '' }); renderLines(lines.length - 1); changed(); });
  $('pasteToggle').addEventListener('click', function () {
    var open = $('pasteBox').hidden; $('pasteBox').hidden = !open; this.setAttribute('aria-expanded', String(open));
    if (open) $('paste').focus();
  });
  $('pasteGo').addEventListener('click', function () {
    var turns = ObiChat.parseTurns($('paste').value);
    if (!turns.length) { setStatus('No labelled lines found. Start each line with User: or Obi:'); return; }
    lines = [];
    turns.forEach(function (t) { if (t.question) lines.push({ role: 'user', text: t.question }); if (t.answer) lines.push({ role: 'obi', text: t.answer }); });
    $('paste').value = ''; $('pasteBox').hidden = true; $('pasteToggle').setAttribute('aria-expanded', 'false');
    renderLines(); changed(); setStatus('Filled ' + lines.length + ' lines.', true);
  });

  function toTurns() {
    var turns = [], warns = [], cur = null;
    lines.forEach(function (ln, i) {
      var txt = (ln.text || '').trim();
      if (ln.role === 'user') { cur = { question: txt, answer: '' }; turns.push(cur); }
      else {
        if (!cur || cur.answer) { warns.push('Obi line ' + (i + 1) + ' needs a User line before it, so it was skipped.'); return; }
        cur.answer = txt;
      }
    });
    var ok = turns.filter(function (t) { if (!t.answer && turns.length > 1) { warns.push('A User line without an Obi reply was skipped.'); return false; } return true; });
    return { turns: ok, warnings: warns };
  }
  function autoName(turns) {
    var names = [];
    turns.forEach(function (t) { (t.question.match(/@\[([^\]]+)\]|@([\p{L}\p{N}_\-]+)/gu) || []).forEach(function (m) { var n = m.replace(/[@\[\]]/g, '').split(' ')[0]; if (names.indexOf(n) < 0) names.push(n); }); });
    return 'Obi chat' + (names.length ? ' ' + names.join(' ') : '');
  }

  // ---------- build + preview ----------
  function build() {
    var tt = toTurns(), size = radio('size');
    if (!fnameTouched) fname.value = autoName(tt.turns);
    var r = ObiChat.build(PARTS, GLYPHS, { turns: tt.turns, asker: asker.value, avatar: avatar, smartQuotes: smart.checked, name: baseName(), size: size });
    current = r; current.size = size;
    $('meta').textContent = r.info.width + ' × ' + r.info.height + ' · ' + r.info.seconds.toFixed(1) + ' s' + (r.info.turns > 1 ? ' · ' + r.info.turns + ' exchanges' : '');
    $('stage').style.setProperty('--ar', r.info.width / r.info.height);
    var all = tt.warnings.concat(r.warnings), w = $('warn');
    if (all.length) { w.hidden = false; w.innerHTML = '<ul></ul>'; all.forEach(function (x) { var li = document.createElement('li'); li.textContent = x; w.firstChild.appendChild(li); }); }
    else w.hidden = true;
    updateSpec();
    mount(r.json);
  }
  function mount(json) {
    var keep = anim ? anim.currentFrame : 0;
    if (anim) anim.destroy();
    $('player').innerHTML = '';
    if (typeof lottie === 'undefined') { $('player').textContent = 'The preview didn’t load. Check your connection and reload.'; return; }
    anim = lottie.loadAnimation({ container: $('player'), renderer: 'svg', loop: true, autoplay: false, animationData: JSON.parse(JSON.stringify(json)), rendererSettings: { preserveAspectRatio: 'xMidYMid meet' } });
    var total = json.op; $('scrub').max = total - 1;
    anim.addEventListener('enterFrame', tick);
    anim.addEventListener('DOMLoaded', function () {
      var f = Math.min(keep, total - 1);
      if (playing && !busy) anim.goToAndPlay(f, true); else anim.goToAndStop(f, true);
      tick();
    });
  }
  function tick() { if (!anim) return; var f = Math.floor(anim.currentFrame); $('scrub').value = f; $('tc').textContent = (f / FPS).toFixed(1) + ' s'; }
  var ICON_PAUSE = '<rect x="3" y="2" width="3.5" height="12" rx="1"/><rect x="9.5" y="2" width="3.5" height="12" rx="1"/>';
  var ICON_PLAY = '<path d="M4 2.6v10.8a1 1 0 0 0 1.5.86l9-5.4a1 1 0 0 0 0-1.72l-9-5.4A1 1 0 0 0 4 2.6z"/>';
  function setPlaying(on) { playing = on; $('playIcon').innerHTML = on ? ICON_PAUSE : ICON_PLAY; $('play').setAttribute('aria-label', on ? 'Pause' : 'Play'); }
  $('play').addEventListener('click', function () { if (!anim) return; setPlaying(!playing); if (playing) anim.play(); else anim.pause(); });
  $('scrub').addEventListener('input', function () { if (!anim) return; setPlaying(false); anim.goToAndStop(+this.value, true); tick(); });

  var timer;
  function changed() { clearTimeout(timer); timer = setTimeout(function () { store('obi3-lines', JSON.stringify(lines)); store('obi2-asker', asker.value); build(); }, 400); }
  asker.addEventListener('input', changed);
  smart.addEventListener('change', build);
  fname.addEventListener('input', function () { fnameTouched = !!fname.value.trim(); store('obi2-fname', fnameTouched ? fname.value : ''); updateSpec(); });
  $('sizes').addEventListener('change', function () { store('obi4-size', radio('size')); setStatus(''); build(); });
  $('formats').addEventListener('change', function () { store('obi4-format', radio('format')); setStatus(''); updateSpec(); });

  function updateSpec() {
    if (!current) return;
    var f = radio('format'), w = current.info.width, h = current.info.height, s = current.info.seconds.toFixed(1) + ' s';
    var g = GIF_DIMS[current.size], n = current.stills.length;
    var txt = {
      mp4: w + ' × ' + h + ' video, ' + s + '. Plays everywhere: social, slides, Slack.',
      gif: g[0] + ' × ' + g[1] + ' GIF kept under 1 MB, plus a still fallback image for Outlook. Saved together as a ZIP.',
      png: n > 1 ? n + ' stills at ' + w + ' × ' + h + ', one per exchange, saved as a ZIP.' : 'A ' + w + ' × ' + h + ' still of the finished exchange.',
      json: 'Lottie animation (' + w + ' × ' + h + ') for web pages and apps. Text is drawn as shapes, so no fonts are needed.'
    }[f];
    $('spec').textContent = txt;
    $('goText').textContent = 'Download ' + FORMAT_LABEL[f];
  }

  // ---------- photo ----------
  function processAvatar() {
    if (!avatarRaw) { avatar = null; $('avatarImg').src = PARTS.avatar; build(); return; }
    var img = avatarRaw, S = 1024, c = document.createElement('canvas'); c.width = c.height = S;
    var x = c.getContext('2d'), m = Math.min(img.width, img.height);
    x.fillStyle = '#fff'; x.fillRect(0, 0, S, S);
    if (bw.checked) x.filter = 'grayscale(1) contrast(1.05)';
    x.drawImage(img, (img.width - m) / 2, (img.height - m) / 2, m, m, 0, 0, S, S);
    avatar = c.toDataURL('image/jpeg', 0.85); $('avatarImg').src = avatar; build();
  }
  $('avatarFile').addEventListener('change', function () {
    var f = this.files && this.files[0]; if (!f) return;
    var rd = new FileReader();
    rd.onload = function () { var img = new Image(); img.onload = function () { avatarRaw = img; $('avatarReset').hidden = false; processAvatar(); }; img.onerror = function () { setStatus('That file isn’t an image the browser can read. Try a JPG or PNG.'); }; img.src = rd.result; };
    rd.readAsDataURL(f); this.value = '';
  });
  bw.addEventListener('change', function () { if (avatarRaw) processAvatar(); });
  $('avatarReset').addEventListener('click', function () { avatarRaw = null; this.hidden = true; processAvatar(); });

  // ---------- saving ----------
  function setStatus(msg, ok) { var s = $('status'); s.textContent = msg || ''; s.className = 'status' + (ok ? ' ok' : ''); }
  function baseName() { return (fname.value.trim() || 'Obi chat').replace(/\.(json|mp4|png|gif|zip)$/i, '').replace(/[\\/:*?"<>|]+/g, ' ').trim(); }
  function kb(n) { return n < 1048576 ? Math.round(n / 1024) + ' KB' : (n / 1048576).toFixed(2) + ' MB'; }

  // Published as a Claude artifact the page saves through the viewer's own save prompt; anywhere else it is a normal browser download.
  var downloadsP = null;
  function getDownloads() {
    if (downloadsP) return downloadsP;
    if (!(window.claude && typeof window.claude.use === 'function')) return Promise.resolve(null);
    downloadsP = Promise.race([
      window.claude.use('downloads').catch(function () { return null; }),
      new Promise(function (res) { setTimeout(function () { res(null); }, 10000); })
    ]);
    return downloadsP;
  }
  getDownloads();   // resolve early so the click doesn't wait
  function save(filename, blob, note) {
    return getDownloads().then(function (dls) {
      if (!dls) return direct();
      return dls.save({ filename: filename, data: blob }).then(function () { setStatus('Saved ' + filename + ' · ' + kb(blob.size) + (note ? '. ' + note : ''), true); return true; }, function (e) {
        var c = e && e.code;
        if (c === 'declined') { setStatus('Download cancelled.'); return false; }
        if (c === 'rate_limited') { setStatus('A save prompt is already open. Answer it, then try again.'); return false; }
        if (c === 'too_large') { setStatus('That file is too large to save here. Try a shorter conversation or the GIF.'); return false; }
        downloadsP = Promise.resolve(null); return direct();
      });
    });
    function direct() {
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove();
      var s = $('status'); s.className = 'status ok'; s.textContent = 'Downloaded ' + filename + ' · ' + kb(blob.size) + '. ' + (note ? note + ' ' : '');
      var again = document.createElement('a'); again.href = url; again.download = filename; again.textContent = 'Didn’t start? Save it again';
      s.appendChild(again);
      setTimeout(function () { URL.revokeObjectURL(url); }, 120000);
      return true;
    }
  }

  // ---------- rendering helpers ----------
  function offscreen(json) {
    var host = $('renderHost'); host.innerHTML = '';
    host.style.width = json.w + 'px'; host.style.height = json.h + 'px';
    var ra = lottie.loadAnimation({ container: host, renderer: 'svg', loop: false, autoplay: false, animationData: JSON.parse(JSON.stringify(json)) });
    return new Promise(function (res) { ra.addEventListener('DOMLoaded', function () { var svg = host.querySelector('svg'); svg.setAttribute('width', json.w); svg.setAttribute('height', json.h); res({ anim: ra, svg: svg, host: host }); }); });
  }
  var ser = new XMLSerializer();
  function frameImage(off, f) {
    off.anim.goToAndStop(f, true);
    var url = URL.createObjectURL(new Blob([ser.serializeToString(off.svg)], { type: 'image/svg+xml' }));
    var img = new Image(); img.src = url;
    return img.decode().then(function () { URL.revokeObjectURL(url); return img; }, function (e) { URL.revokeObjectURL(url); throw e; });
  }
  function drawFrame(ctx, img, w, h) {
    ctx.fillStyle = current.background; ctx.fillRect(0, 0, w, h);
    ctx.imageSmoothingEnabled = true; ctx.imageSmoothingQuality = 'high';
    ctx.drawImage(img, 0, 0, w, h);
  }
  function canvas(w, h) { var c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function toBlob(c, type, q) { return new Promise(function (res) { c.toBlob(res, type, q); }); }
  function progress(frac, text) { $('barFill').style.width = (Math.min(1, frac) * 100).toFixed(1) + '%'; if (text) $('progText').textContent = text; }
  function lock(on) {
    busy = on ? { cancelled: false } : null;
    ['go', 'addLine', 'pasteGo'].forEach(function (id) { $(id).disabled = !!on; });
    document.querySelectorAll('#sizes input,#formats input').forEach(function (i) { i.disabled = !!on; });
    $('progress').hidden = !on; if (!on) progress(0, '');
    if (anim) { if (on) anim.pause(); else if (playing) anim.play(); }
    return busy;
  }
  function checkCancel(job) { if (job.cancelled) throw { cancel: true }; }
  var nextTick = function () { return new Promise(function (r) { setTimeout(r, 0); }); };

  // ---------- ZIP (store only: GIF/PNG are already compressed) ----------
  var CRC = (function () { var t = new Uint32Array(256); for (var n = 0; n < 256; n++) { var c = n; for (var k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
  function crc32(u8) { var c = 0xFFFFFFFF; for (var i = 0; i < u8.length; i++) c = CRC[(c ^ u8[i]) & 0xFF] ^ (c >>> 8); return (c ^ 0xFFFFFFFF) >>> 0; }
  function makeZip(files) {   // files: [{name, data:Uint8Array}]
    var enc = new TextEncoder(), parts = [], central = [], offset = 0;
    var d = new Date(), dosT = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), dosD = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    files.forEach(function (f) {
      var name = enc.encode(f.name), crc = crc32(f.data), size = f.data.length;
      var h = new DataView(new ArrayBuffer(30));
      h.setUint32(0, 0x04034b50, true); h.setUint16(4, 20, true); h.setUint16(6, 0x0800, true); h.setUint16(8, 0, true);
      h.setUint16(10, dosT, true); h.setUint16(12, dosD, true); h.setUint32(14, crc, true); h.setUint32(18, size, true); h.setUint32(22, size, true);
      h.setUint16(26, name.length, true); h.setUint16(28, 0, true);
      parts.push(h.buffer, name, f.data);
      var c = new DataView(new ArrayBuffer(46));
      c.setUint32(0, 0x02014b50, true); c.setUint16(4, 20, true); c.setUint16(6, 20, true); c.setUint16(8, 0x0800, true); c.setUint16(10, 0, true);
      c.setUint16(12, dosT, true); c.setUint16(14, dosD, true); c.setUint32(16, crc, true); c.setUint32(20, size, true); c.setUint32(24, size, true);
      c.setUint16(28, name.length, true); c.setUint32(42, offset, true);
      central.push(c.buffer, name);
      offset += 30 + name.length + size;
    });
    var cSize = central.reduce(function (s, b) { return s + b.byteLength; }, 0);
    var e = new DataView(new ArrayBuffer(22));
    e.setUint32(0, 0x06054b50, true); e.setUint16(8, files.length, true); e.setUint16(10, files.length, true); e.setUint32(12, cSize, true); e.setUint32(16, offset, true);
    return new Blob(parts.concat(central, [e.buffer]), { type: 'application/zip' });
  }
  function bytes(blob) { return blob.arrayBuffer().then(function (b) { return new Uint8Array(b); }); }

  // ---------- exports ----------
  function fileStem() { return baseName() + ' ' + SIZE_TAG[current.size]; }

  function exportJSON() { return save(fileStem() + '.json', new Blob([JSON.stringify(current.json)], { type: 'application/json' })); }

  async function exportPNG(job) {
    var off = await offscreen(current.json), w = current.info.width, h = current.info.height, outs = [];
    try {
      for (var i = 0; i < current.stills.length; i++) {
        checkCancel(job); progress(i / current.stills.length, 'Rendering still ' + (i + 1) + ' of ' + current.stills.length);
        var c = canvas(w, h); drawFrame(c.getContext('2d'), await frameImage(off, current.stills[i].frame), w, h);
        outs.push({ name: fileStem() + (current.stills.length > 1 ? ' ' + (i + 1) : '') + '.png', blob: await toBlob(c, 'image/png') });
      }
    } finally { off.anim.destroy(); off.host.innerHTML = ''; }
    if (outs.length === 1) return save(outs[0].name, outs[0].blob);
    var files = []; for (var k = 0; k < outs.length; k++) files.push({ name: outs[k].name, data: await bytes(outs[k].blob) });
    return save(fileStem() + ' stills.zip', makeZip(files));
  }

  async function pickCodec(w, h) {
    var opts = [['avc1.640028', 'avc'], ['avc1.4d0028', 'avc'], ['avc1.42002a', 'avc'], ['vp09.00.40.08', 'vp9']];
    for (var i = 0; i < opts.length; i++) { try { var s = await VideoEncoder.isConfigSupported({ codec: opts[i][0], width: w, height: h, bitrate: 8e6, framerate: FPS }); if (s.supported) return { codec: opts[i][0], mux: opts[i][1] }; } catch (e) {} }
    return null;
  }
  async function exportMP4(job) {
    if (typeof VideoEncoder === 'undefined' || typeof Mp4Muxer === 'undefined') { setStatus('This browser can’t make MP4s. Open the page in Chrome or Edge, or choose GIF.'); return false; }
    var w = current.info.width, h = current.info.height, total = current.json.op;
    var pick = await pickCodec(w, h); if (!pick) { setStatus('This browser has no usable video encoder. Open the page in Chrome or Edge.'); return false; }
    var off = await offscreen(current.json), enc = null;
    try {
      var c = canvas(w, h), ctx = c.getContext('2d');
      var muxer = new Mp4Muxer.Muxer({ target: new Mp4Muxer.ArrayBufferTarget(), video: { codec: pick.mux, width: w, height: h, frameRate: FPS }, fastStart: 'in-memory' });
      var encErr = null;
      enc = new VideoEncoder({ output: function (ch, meta) { muxer.addVideoChunk(ch, meta); }, error: function (e) { encErr = e; } });
      var cfg = { codec: pick.codec, width: w, height: h, bitrate: w * h > 1.5e6 ? 9e6 : 7e6, framerate: FPS }; if (pick.mux === 'avc') cfg.avc = { format: 'avc' };
      enc.configure(cfg);
      var t0 = performance.now();
      for (var f = 0; f < total; f++) {
        checkCancel(job); if (encErr) throw encErr;
        drawFrame(ctx, await frameImage(off, f), w, h);
        var vf = new VideoFrame(c, { timestamp: Math.round(f * 1e6 / FPS), duration: Math.round(1e6 / FPS) });
        enc.encode(vf, { keyFrame: f % 48 === 0 }); vf.close();
        while (enc.encodeQueueSize > 6) await new Promise(function (r) { setTimeout(r, 2); });
        if (f % 4 === 0) { var el = (performance.now() - t0) / 1000, left = Math.round(el / (f + 1) * (total - f - 1)); progress((f + 1) / total, 'Rendering frame ' + (f + 1) + ' of ' + total + (f > 12 ? ' · about ' + left + ' s left' : '')); }
      }
      await enc.flush(); muxer.finalize();
      if (encErr) throw encErr;
      progress(1, 'Saving…');
      var ok = await save(fileStem() + '.mp4', new Blob([muxer.target.buffer], { type: 'video/mp4' }));
      if (ok && pick.mux === 'vp9') setStatus('Saved as VP9, which plays in Chrome and VLC but not QuickTime. Use Chrome for H.264.', true);
      return ok;
    } finally {
      try { if (enc && enc.state !== 'closed') enc.close(); } catch (e) {}
      off.anim.destroy(); off.host.innerHTML = '';
    }
  }

  // Email GIF: one shared palette, unchanged pixels sent as transparent, repeated frames merged.
  // If the file is over budget it steps down frame rate, then size, until it fits.
  async function renderGifFrames(job, off, gw, gh, fps, from, to, phase) {
    var G = window.GIFENC, c = canvas(gw, gh), ctx = c.getContext('2d', { willReadFrequently: true });
    var step = FPS / fps, list = [];
    for (var t = from; t < to; t += step) list.push(Math.round(t));
    // palette from frames spread across the animation (plus the stills, where all the colour is)
    var sampleFrames = [];
    for (var s = 0; s < 10; s++) sampleFrames.push(list[Math.floor(s * (list.length - 1) / 9)]);
    current.stills.forEach(function (st) { if (st.frame < to) sampleFrames.push(st.frame); });
    var px = gw * gh, sample = new Uint8ClampedArray(px * 4 * sampleFrames.length);
    for (var i = 0; i < sampleFrames.length; i++) {
      checkCancel(job);
      drawFrame(ctx, await frameImage(off, sampleFrames[i]), gw, gh);
      sample.set(ctx.getImageData(0, 0, gw, gh).data, i * px * 4);
    }
    var palette = G.quantize(sample, 255, { format: 'rgb565' });
    var frames = [];
    for (var k = 0; k < list.length; k++) {
      checkCancel(job);
      drawFrame(ctx, await frameImage(off, list[k]), gw, gh);
      frames.push(G.applyPalette(dither(ctx.getImageData(0, 0, gw, gh).data, gw), palette, 'rgb565'));
      if (k % 3 === 0) progress(phase[0] + (phase[1] - phase[0]) * k / list.length, 'Rendering GIF frame ' + (k + 1) + ' of ' + list.length);
    }
    return { frames: frames, palette: palette, fps: fps };
  }
  // ordered (Bayer) dither: hides palette banding in the soft background glows. The pattern is fixed per pixel,
  // so pixels that don't change between frames stay identical and still compress as transparent.
  var BAYER = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
  function dither(d, w) {
    for (var i = 0, p = 0; i < d.length; i += 4, p++) {
      var x = p % w, y = (p / w) | 0, o = (BAYER[(y & 3) * 4 + (x & 3)] - 7.5) * 0.9;
      d[i] += o; d[i + 1] += o * 0.5; d[i + 2] += o;
    }
    return d;
  }
  function encodeGif(set, gw, gh, fps) {
    var G = window.GIFENC, gif = G.GIFEncoder(), pal = set.palette.slice();
    while (pal.length < 256) pal.push([0, 0, 0]);
    var TI = 255, n = gw * gh, prev = null, pending = null;
    var flush = function () { if (pending) gif.writeFrame(pending.idx, gw, gh, pending.opts); };
    for (var j = 0, k = 0; k < set.frames.length; j++, k = Math.round(j * set.fps / fps)) {
      var idx = set.frames[k];
      var tA = Math.round(j * 100 / fps), tB = Math.round((j + 1) * 100 / fps), delay = (tB - tA) * 10;
      if (prev) {
        var out = new Uint8Array(n), changed = 0;
        for (var p = 0; p < n; p++) { if (idx[p] === prev[p]) out[p] = TI; else { out[p] = idx[p]; changed++; } }
        if (!changed) { pending.opts.delay += delay; continue; }
        flush();
        pending = { idx: out, opts: { delay: delay, transparent: true, transparentIndex: TI, dispose: 1 } };
      } else {
        pending = { idx: idx, opts: { palette: pal, delay: delay, repeat: 0, dispose: 1 } };
      }
      prev = idx;
    }
    flush(); gif.finish();
    return gif.bytes();
  }
  async function exportGIF(job) {
    if (!window.GIFENC) { setStatus('The GIF encoder didn’t load. Reload the page.'); return false; }
    var size = current.size, dims = GIF_DIMS[size], from = current.poster, to = current.json.op;
    var off = await offscreen(current.json), out = null, used = null;
    try {
      // ladder of [scale, fps]: drop frame rate first, then size; each size is rendered once at 12 fps
      var ladder = [[1, 12], [1, 8], [0.84, 8], [0.7, 8], [0.7, 6]], set = null, lastKey = '';
      for (var i = 0; i < ladder.length && !out; i++) {
        var sc = ladder[i][0], fps = ladder[i][1];
        var gw = Math.round(dims[0] * sc / 2) * 2, gh = Math.round(dims[1] * sc / 2) * 2, key = gw + 'x' + gh;
        if (key !== lastKey) { set = await renderGifFrames(job, off, gw, gh, 12, from, to, [i / ladder.length * 0.9, (i + 1) / ladder.length * 0.9]); lastKey = key; }
        progress((i + 0.95) / ladder.length * 0.9, 'Compressing ' + gw + ' × ' + gh + ' at ' + fps + ' fps…');
        await nextTick(); checkCancel(job);
        var bytesOut = encodeGif(set, gw, gh, fps);
        if (bytesOut.length <= GIF_BUDGET || i === ladder.length - 1) { out = bytesOut; used = { w: gw, h: gh, fps: fps }; }
      }
      // fallback still: the finished last exchange at 2× the GIF size for sharp retina display
      progress(0.95, 'Making the fallback image…');
      var fw = Math.min(current.info.width, used.w * 2), fh = Math.round(fw * current.info.height / current.info.width);
      var fc = canvas(fw, fh); drawFrame(fc.getContext('2d'), await frameImage(off, current.stills[current.stills.length - 1].frame), fw, fh);
      var fallback = await toBlob(fc, 'image/jpeg', 0.9);
    } finally { off.anim.destroy(); off.host.innerHTML = ''; }
    var stem = fileStem();
    var zip = makeZip([{ name: stem + '.gif', data: out }, { name: stem + ' fallback.jpg', data: await bytes(fallback) }]);
    progress(1, 'Saving…');
    return save(stem + ' email GIF.zip', zip, 'Contains the GIF (' + used.w + ' × ' + used.h + ' at ' + used.fps + ' fps, ' + kb(out.length) + (out.length > GIF_BUDGET ? ' (over 1 MB even at the smallest setting; shorten the conversation)' : '') + ') and a fallback JPG (' + kb(fallback.size) + ').');
  }

  $('cancel').addEventListener('click', function () { if (busy) busy.cancelled = true; });
  $('go').addEventListener('click', async function () {
    if (!current || busy) return;
    var f = radio('format');
    setStatus('');
    if (f === 'json') { exportJSON(); return; }
    var job = lock(true);
    try {
      if (f === 'mp4') await exportMP4(job);
      else if (f === 'gif') await exportGIF(job);
      else await exportPNG(job);
    } catch (e) {
      setStatus(e && e.cancel ? 'Export cancelled.' : 'The export didn’t finish (' + ((e && e.message) || 'render error') + '). Try again.');
      if (!(e && e.cancel)) console.error(e);
    } finally { lock(false); }
  });

  renderLines();
  build();
})();
