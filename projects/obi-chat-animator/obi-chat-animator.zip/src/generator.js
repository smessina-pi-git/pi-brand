/* Obi chat animation generator v3 — builds the Lottie from scratch.
   ObiChat.build(parts, glyphs, opts) -> {json, warnings, info, stills, poster}
   parts  : {piShapes, circleShapes, sendShapes, avatar}
   glyphs : {Regular:[...], Bold:[...]}
   opts   : {turns:[{question, answer}], asker, avatar, smartQuotes, name, size}
   size   : 'square' (1080×1080) | 'wide' (1920×1080) | 'tall' (1080×1920) */
(function (root) {
  'use strict';
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  var r2 = function (n) { return Math.round(n * 100) / 100; };

  // ---------- palette (Obi product style) ----------
  var C = {
    bg: [0.961, 0.949, 0.988],         // #F5F2FC lavender page
    ink: [0.18, 0.122, 0.267],         // #2E1F44 text
    muted: [0.42, 0.39, 0.48],         // #6B6280 labels
    placeholder: [0.55, 0.53, 0.6],    // placeholder grey
    purple: [0.353, 0.122, 0.722],     // #5A1FB8 sparkle, caret, dots
    glowA: [0.482, 0.294, 0.878],      // #7B4BE0 top-left glow
    glowB: [0.239, 0.639, 0.933],      // #3DA3EE bottom-right glow
    gradA: [0.416, 0.231, 0.847],      // #6A3BD8 border left
    gradB: [0.239, 0.639, 0.933],      // #3DA3EE border right
    hair: [0.894, 0.867, 0.957],       // #E4DDF4 bubble hairline
    white: [1, 1, 1]
  };
  var BG_HEX = '#f5f2fc';
  var SIZES = { square: [1080, 1080], wide: [1920, 1080], tall: [1080, 1920] };
  var FS = 38, LH = 54, ASC = 0.75;    // one size for all chat text; sized to stay legible at 600px email width
  var W = 1080, H = 1080, FR = 24;

  // ---------- measuring + layout ----------
  function makeMeasure(glyphs) {
    var Wd = {};
    Object.keys(glyphs).forEach(function (s) { Wd[s] = {}; glyphs[s].forEach(function (c) { Wd[s][c.ch] = c.w; }); });
    return function (ch, bold, size) {
      var t = Wd[bold ? 'Bold' : 'Regular']; var w = t[ch]; if (w === undefined) w = t['?'];
      return w * (size || FS) / 100;
    };
  }
  // chars: [{ch, bold}] -> lines of runs, with per-char x; mirrors lottie-web box wrapping
  function layoutMixed(chars, maxW, measure, size) {
    var lines = [[]], cur = 0, lastSpace = -1, i;
    var x = 0, pos = [];
    for (i = 0; i < chars.length; i++) {
      var c = chars[i];
      if (c.ch === '\r') { lines.push([]); cur++; x = 0; lastSpace = -1; pos.push(null); continue; }
      if (c.ch === ' ') lastSpace = i;
      var w = measure(c.ch, c.bold, size);
      if (x + w > maxW && c.ch !== ' ' && lastSpace !== -1) {
        // move everything after lastSpace to a new line
        var moved = lines[cur].splice(lines[cur].findIndex(function (p) { return p.i === lastSpace; }) + 1);
        lines[cur].pop();   // drop the breaking space
        pos[lastSpace] = null;
        lines.push([]); cur++; x = 0;
        moved.forEach(function (p) { p.x = x; p.line = cur; x += p.w; lines[cur].push(p); pos[p.i] = p; });
        lastSpace = -1;
      }
      var p = { i: i, ch: c.ch, bold: c.bold, x: x, w: w, line: cur };
      lines[cur].push(p); pos.push(p); x += w;
    }
    var runs = [];
    lines.forEach(function (ln, li) {
      var run = null;
      ln.forEach(function (p) {
        if (!run || run.bold !== p.bold) { run = { line: li, bold: p.bold, x: p.x, text: '', from: p.i, to: p.i, w: 0 }; runs.push(run); }
        run.text += p.ch; run.to = p.i; run.w = p.x + p.w - run.x;
      });
    });
    runs.forEach(function (r) { var t = r.text.replace(/\s+$/, ''); r.w -= (r.text.length - t.length) * measure(' ', r.bold, size); r.text = t; });
    return { lines: lines.length, runs: runs.filter(function (r) { return r.text; }), pos: pos };
  }

  // ---------- text helpers ----------
  function smarten(s) {
    return s.replace(/(^|[\s(\[{"“])'/g, '$1‘').replace(/'/g, '’').replace(/(^|[\s(\[{‘])"/g, '$1“').replace(/"/g, '”').replace(/\.\.\./g, '…');
  }
  function clean(s, smart) {
    s = (s || '').replace(/\r\n?/g, '\n').replace(/[ \t]+/g, ' ').trim().replace(/ *\n */g, '\r');
    return smart ? smarten(s) : s;
  }
  function parseMentions(q) {
    var out = [], re = /@\[([^\]]+)\]|@([\p{L}\p{N}_](?:[\p{L}\p{N}_\-.]*[\p{L}\p{N}_])?)/gu, m, last = 0, names = [];
    var push = function (str, bold) { for (var i = 0; i < str.length; i++) out.push({ ch: str[i], bold: bold }); };
    while ((m = re.exec(q))) {
      push(q.slice(last, m.index), false);
      var name = m[1] || m[2]; names.push(name);
      push(name, true);
      last = m.index + m[0].length;
    }
    push(q.slice(last), false);
    return { chars: out, names: names };
  }

  // ---------- lottie primitives ----------
  var ix = 0;
  var EASE = {
    io: { i: { x: [0.667], y: [1] }, o: { x: [0.333], y: [0] } },    // ease in-out
    out: { i: { x: [0.2], y: [1] }, o: { x: [0.4], y: [0] } },       // decelerate
    in: { i: { x: [0.8], y: [1] }, o: { x: [0.55], y: [0] } },       // accelerate (exits)
    lin: { i: { x: [1], y: [1] }, o: { x: [0], y: [0] } }
  };
  function K(v) { return { a: 0, k: v }; }
  // [[t, v, ease?], ...] — ease names the curve leaving that key: 'io' (default), 'out', 'in', 'lin', 'hold'
  function keys(list) {
    return { a: 1, k: list.map(function (k, n) {
      var kf = { t: k[0], s: Array.isArray(k[1]) ? k[1] : [k[1]] };
      if (n < list.length - 1) {
        if (k[2] === 'hold') kf.h = 1;
        else { var e = EASE[k[2] || 'io']; kf.i = e.i; kf.o = e.o; }
      }
      return kf;
    }) };
  }
  // spatial (position) keys: scalar easing + tangents, as After Effects writes them
  function posKeys(list) {
    var k = keys(list);
    k.k.forEach(function (kf) {
      if (kf.i) { kf.i = { x: kf.i.x[0], y: kf.i.y[0] }; kf.o = { x: kf.o.x[0], y: kf.o.y[0] }; }
      if (!kf.h) { kf.to = [0, 0, 0]; kf.ti = [0, 0, 0]; }
    });
    return k;
  }
  // spring-like pop: 0 → overshoot → settle
  function popScale(t0, over, settle) {
    return keys([[t0, [0, 0, 100], 'out'], [t0 + (over || 7), [110, 110, 100], 'io'], [t0 + (settle || 12), [100, 100, 100]]]);
  }
  function tr(p, a, s, o) { return { p: K(p || [0, 0]), a: K(a || [0, 0]), s: K(s || [100, 100]), r: K(0), o: K(o == null ? 100 : o), sk: K(0), sa: K(0) }; }
  function fill(c, o) { return { ty: 'fl', c: K(c.concat([1])), o: typeof o === 'object' ? o : K(o == null ? 100 : o), r: 1 }; }
  function stroke(c, w, o) { return { ty: 'st', c: K(c.concat([1])), o: typeof o === 'object' ? o : K(o == null ? 100 : o), w: typeof w === 'object' ? w : K(w), lc: 2, lj: 2 }; }
  function rect(w, h, r, p) { return { ty: 'rc', d: 1, s: K([w, h]), p: K(p || [0, 0]), r: K(r) }; }
  function ellipse(d, p) { return { ty: 'el', d: 1, s: typeof d === 'object' && !Array.isArray(d) ? d : K(Array.isArray(d) ? d : [d, d]), p: K(p || [0, 0]) }; }
  function group(items, nm, t) { return { ty: 'gr', it: items.concat([Object.assign({ ty: 'tr', nm: 'Transform' }, t || tr())]), nm: nm || 'Group' }; }
  function radialGlow(cx, cy, r, color, alpha) {
    return { ty: 'gf', t: 2, o: K(100), r: 1, s: K([cx, cy]), e: K([cx + r, cy]), h: K(0), a: K(0),
      g: { p: 2, k: K([0, color[0], color[1], color[2], 1, color[0], color[1], color[2], 0, alpha, 0.55, alpha * 0.35, 1, 0]) } };
  }
  function blur(amount) {
    return [{ ty: 29, nm: 'Gaussian Blur', np: 5, en: 1, ef: [
      { ty: 0, nm: 'Blurriness', v: K(amount) }, { ty: 7, nm: 'Blur Dimensions', v: K(1) }, { ty: 7, nm: 'Repeat Edge Pixels', v: K(0) }] }];
  }
  function layerBase(nm, ty, ip, op) {
    return { ddd: 0, ind: ++ix, ty: ty, nm: nm, sr: 1, ao: 0, ip: ip || 0, op: op == null ? 99999 : op, st: 0, bm: 0,
      ks: { o: K(100), r: K(0), p: K([0, 0, 0]), a: K([0, 0, 0]), s: K([100, 100, 100]) } };
  }
  function shapeLayer(nm, shapes, ip, op) { var l = layerBase(nm, 4, ip, op); l.shapes = shapes; return l; }
  function nullLayer(nm) { var l = layerBase(nm, 3); l.ks.o = K(0); return l; }
  function textDoc(t, size, font, color, lh, sz, ps) {
    var d = { t: t, s: size, f: font, fc: color, ca: 0, j: 0, tr: 0, lh: lh, ls: 0 };
    if (sz) { d.sz = sz; d.ps = ps; }
    return d;
  }
  function textLayer(nm, doc, pos, ip, op) {
    var l = layerBase(nm, 5, ip, op);
    l.ks.p = K([pos[0], pos[1], 0]);
    l.t = { d: { k: [{ s: doc, t: 0 }] }, p: {}, m: { g: 1, a: K([0, 0]) }, a: [] };
    return l;
  }
  // typing selector: chars beyond `start` are hidden; start sweeps 0→100 between t0..t1
  function typingAnimator(t0, t1) {
    return { nm: 'Type', s: { t: 0, xe: K(0), ne: K(0), a: K(100), b: 1, rn: 0, sh: 1, sm: K(0), r: 1,
      s: { a: 1, k: [{ t: t0, s: [0], i: { x: [1], y: [1] }, o: { x: [0], y: [0] } }, { t: t1, s: [100] }] } },
      a: { o: K(0) } };
  }
  // word ramp-in: words fade in and rise into place one after another
  function wordRise(t0, t1) {
    return { nm: 'Words', s: { t: 0, xe: K(100), ne: K(0), a: K(100), b: 3, rn: 0, sh: 2, sm: K(100), r: 1,
      o: { a: 1, k: [{ t: t0, s: [-100], i: { x: [0.5], y: [1] }, o: { x: [0.3], y: [0] } }, { t: t1, s: [100] }] } },
      a: { o: K(0), p: K([0, 18, 0]) } };
  }
  function sparkle(size, color) { // 4-point star + two small ones
    var big = { ty: 'sr', sy: 1, d: 1, pt: K(4), p: K([0, 0]), r: K(0), ir: K(size * 0.13), is: K(0), or: K(size * 0.5), os: K(0) };
    var s1 = { ty: 'sr', sy: 1, d: 1, pt: K(4), p: K([size * 0.42, -size * 0.42]), r: K(0), ir: K(size * 0.05), is: K(0), or: K(size * 0.19), os: K(0) };
    var s2 = { ty: 'sr', sy: 1, d: 1, pt: K(4), p: K([size * 0.42, size * 0.42]), r: K(0), ir: K(size * 0.04), is: K(0), or: K(size * 0.15), os: K(0) };
    return group([big, s1, s2, fill(color)], 'Sparkle');
  }

  // ---------- one exchange ----------
  function buildTurn(parts, measure, t, o) {
    ix = 0;
    var warnings = [];
    var first = o.first;
    var qm = parseMentions(t.question);
    var qChars = qm.chars;
    var N = qChars.length;

    // --- geometry ---
    var BOXW = 940, PADX = 44, PADT = 38;
    var AV = 100, LOGO = 88, COL = 120, GAP = 52;
    var BUBW = BOXW - COL - 16, TEXTW = BUBW - PADX * 2;
    var qLay = layoutMixed(qChars, TEXTW, measure);
    if (qLay.lines > 4) warnings.push('Question runs to ' + qLay.lines + ' lines; 1–3 reads best.');
    var qTextH = qLay.lines * LH;
    var boxH = Math.max(214, qTextH + PADT * 2 + 34);     // room for send row
    var BUBH = qTextH + PADT * 2 - 8;

    // reply layout
    var aChars = t.answer.split('').map(function (ch) { return { ch: ch, bold: false }; });
    var aLay = layoutMixed(aChars, TEXTW, measure);
    var replyTextH = aLay.lines * LH;
    var replyH = Math.max(LOGO + 50, replyTextH);
    var convH = BUBH + GAP + replyH;
    var room = Math.round(H * (H > W ? 0.84 : 0.9));
    if (convH > room) warnings.push('This exchange is too tall for the frame. Shorten the answer' + (H > W ? '.' : ', or switch to 9:16.'));

    var cx = W / 2, cy = H / 2;
    var boxTop0 = cy - boxH / 2 + (first ? 30 : 0);  // scene A: box centred (nudged down under the header)
    var convTop = cy - convH / 2;                   // scene B
    var left = cx - BOXW / 2;
    var bubLeft = left, bubTop = convTop;
    var replyTop = convTop + BUBH + GAP;

    // --- timing (24 fps) ---
    var tIn = first ? 14 : 0;                       // box settles
    var tPlace = first ? 20 : 8;                    // placeholder + caret blink
    var tType0 = tPlace;
    var typeDur = Math.max(16, Math.round(N / 1.5));
    var tType1 = tType0 + typeDur;
    var tSend = tType1 + 5;
    var tMorph0 = tSend + 4, tMorph1 = tMorph0 + 12;
    var tLogo = tMorph1 - 2;
    var tDots0 = tLogo + 6, tDots1 = tDots0 + 18;
    var aWords = t.answer.split(/\s+/).filter(Boolean).length;
    var tA0 = tDots1, tA1 = tA0 + Math.min(64, Math.max(16, Math.round(aWords * 2)));
    var tEnd = tA1 + 6;
    var tHoldEnd = tEnd + (o.last ? 66 : 36);
    var layers = [];

    // === Scene A chrome (header) ===
    if (first) {
      var hdY = boxTop0 - 56;
      var hd = textLayer('Header', textDoc('What can I help you with?', 48, 'Roboto-Bold', C.ink, 56), [left + 66, hdY]);
      hd.ks.o = keys([[2, 0, 'out'], [12, 100], [tSend, 100], [tMorph0 + 2, 0]]);
      hd.ks.p = posKeys([[2, [left + 66, hdY + 18, 0], 'out'], [14, [left + 66, hdY, 0]]]);
      layers.push(hd);
      var sp = shapeLayer('Header sparkle', [sparkle(44, C.purple)]);
      sp.ks.p = K([left + 24, hdY - 16, 0]);
      sp.ks.o = keys([[0, 100], [tSend, 100], [tMorph0 + 2, 0]]);
      sp.ks.s = keys([[0, [0, 0, 100], 'out'], [9, [118, 118, 100], 'io'], [15, [100, 100, 100]]]);
      sp.ks.r = keys([[0, -90, 'out'], [15, 0]]);
      layers.push(sp);
    }

    // === Box → bubble (one null drives position; the rects morph) ===
    var boxNull = nullLayer('Box');
    var posList = first ? [[0, [left, boxTop0 + 26, 0], 'out'], [tIn, [left, boxTop0, 0]]] : [];
    posList.push([tMorph0, [left, boxTop0, 0], 'out'], [tMorph1, [bubLeft, bubTop, 0]]);
    boxNull.ks.p = posKeys(posList);
    if (first) boxNull.ks.s = keys([[0, [94, 94, 100], 'out'], [9, [101, 101, 100], 'io'], [tIn, [100, 100, 100]]]);
    layers.push(boxNull);
    var boxInd = boxNull.ind;
    var sizeK = function (dx, dy) { return keys([[tMorph0, [BOXW + dx, boxH + dy], 'out'], [tMorph1, [BUBW + dx, BUBH + dy]]]); };
    var centerK = function (dx, dy) { return keys([[tMorph0, [BOXW / 2 + dx, boxH / 2 + dy], 'out'], [tMorph1, [BUBW / 2 + dx, BUBH / 2 + dy]]]); };

    // soft shadow (real blur)
    var shadow = shapeLayer('Shadow', [group([{ ty: 'rc', d: 1, s: sizeK(-40, -20), p: centerK(0, 22), r: K(28) }, fill(C.purple, 16)])]);
    shadow.ef = blur(70);
    shadow.parent = boxInd; layers.push(shadow);
    // body: gradient focus ring while typing, quiet hairline once it's a bubble
    var body = shapeLayer('Box body', [group([
      { ty: 'rc', d: 1, s: sizeK(0, 0), p: centerK(0, 0), r: K(20) },
      { ty: 'gs', t: 1, s: K([0, boxH / 2]), e: K([BOXW, boxH / 2]), g: { p: 2, k: K([0, C.gradA[0], C.gradA[1], C.gradA[2], 1, C.gradB[0], C.gradB[1], C.gradB[2]]) }, o: keys([[tMorph0, 100], [tMorph1 - 3, 0]]), w: K(3), lc: 2, lj: 2 },
      stroke(C.hair, 2, keys([[tMorph0 + 2, 0], [tMorph1, 100]])),
      fill(C.white)])]);
    body.parent = boxInd; layers.push(body);

    // send button (original artwork) + press ripple
    var sendP = [BOXW - 52, boxH - 50, 0];
    var send = shapeLayer('Send', clone(parts.sendShapes));
    send.parent = boxInd;
    send.ks.p = K(sendP);
    send.ks.s = keys([[tSend - 4, [100, 100, 100]], [tSend, [84, 84, 100], 'out'], [tSend + 4, [106, 106, 100]], [tSend + 8, [100, 100, 100]]]);
    send.ks.o = keys([[tMorph0, 100], [tMorph0 + 5, 0]]);
    layers.push(send);
    var ripple = shapeLayer('Send ripple', [group([ellipse(keys([[tSend, [40, 40], 'out'], [tSend + 12, [120, 120]]])), stroke(C.gradA, keys([[tSend, 5, 'out'], [tSend + 12, 1]]), keys([[tSend, 70, 'out'], [tSend + 12, 0]]))])], tSend, tSend + 13);
    ripple.parent = boxInd; ripple.ks.p = K(sendP);
    layers.push(ripple);

    // placeholder + caret
    var baseY = PADT + ASC * FS;                    // first baseline inside the box
    var ph = textLayer('Placeholder', textDoc('Try asking me to…', FS, 'Roboto-Regular', C.placeholder, LH), [PADX, baseY]);
    ph.parent = boxInd; ph.ks.o = keys([[tType0 - 1, 100, 'hold'], [tType0, 0]]);
    layers.push(ph);
    var caretKeys = [], blink = [];
    for (var b = 0; b < tType0; b += 8) blink.push([b, b % 16 === 0 ? 100 : 0, 'hold']);
    blink.push([tType0, 100, 'hold']);
    var frameOf = function (k) { return tType0 + Math.round(k / Math.max(N, 1) * typeDur); };
    caretKeys.push([0, [PADX + 2, baseY - 33, 0], 'hold']);
    for (var k = 1; k <= N; k++) {
      var p = qLay.pos[k - 1]; if (!p) continue;
      caretKeys.push([frameOf(k), [PADX + p.x + p.w + 3, baseY + p.line * LH - 33, 0], 'hold']);
    }
    blink.push([tType1 + 2, 100, 'hold'], [tType1 + 4, 0, 'hold']);
    var caret = shapeLayer('Caret', [group([rect(3, 44, 1.5, [0, 22]), fill(C.purple)])], 0, tMorph0);
    caret.parent = boxInd; caret.ks.p = keys(caretKeys); caret.ks.o = keys(blink);
    layers.push(caret);

    // question text runs (mentions bold, same colour)
    qLay.runs.forEach(function (r) {
      var L = textLayer(r.text, textDoc(r.text, FS, r.bold ? 'Roboto-Bold' : 'Roboto-Regular', C.ink, LH), [PADX + r.x, baseY + r.line * LH]);
      L.parent = boxInd;
      L.t.a = [typingAnimator(frameOf(r.from), frameOf(r.to + 1))];
      layers.push(L);
    });

    // === Avatar + name (pop in with the bubble) ===
    var avX = left + BUBW + 16 + COL / 2, avY = bubTop + AV / 2 + 4;
    var avNull = nullLayer('Avatar pop'); avNull.ks.p = K([avX, avY, 0]); avNull.ks.s = popScale(tMorph1 - 4);
    layers.push(avNull);
    var ring = shapeLayer('Avatar ring', [group([ellipse(AV + 10), fill(C.white)])], tMorph1 - 4); ring.parent = avNull.ind;
    layers.push(ring);
    var avImg = layerBase('Avatar', 2, tMorph1 - 4);
    avImg.refId = 'avatar';
    avImg.ks.a = K([768, 768, 0]); avImg.ks.s = K([AV / 1536 * 100, AV / 1536 * 100, 100]);
    avImg.hasMask = true;
    var r = 768, kk = 0.5523 * r;
    avImg.masksProperties = [{ inv: false, mode: 'a', o: K(100), x: K(0), pt: K({ c: true, v: [[r, 0], [2 * r, r], [r, 2 * r], [0, r]], i: [[-kk, 0], [0, -kk], [kk, 0], [0, kk]], o: [[kk, 0], [0, kk], [-kk, 0], [0, -kk]] }) }];
    avImg.parent = avNull.ind; layers.push(avImg);
    var avShadow = shapeLayer('Avatar shadow', [group([ellipse(AV), fill(C.purple, 22)])], tMorph1 - 4);
    avShadow.parent = avNull.ind; avShadow.ks.p = K([0, 8, 0]); avShadow.ef = blur(30);
    layers.push(avShadow);
    var nameDoc = textDoc(o.asker, 26, 'Roboto-Regular', C.muted, 26, [COL + 40, 30], [-(COL + 40) / 2, -8]);
    nameDoc.j = 2;
    var nm = textLayer('Asker name', nameDoc, [avX, avY + AV / 2 + 16], tMorph1);
    nm.ks.o = keys([[tMorph1 + 2, 0, 'out'], [tMorph1 + 10, 100]]);
    layers.push(nm);

    // === Obi logo + label ===
    var lgX = left + COL / 2, lgY = replyTop + LOGO / 2 + 6;
    var lgNull = nullLayer('Logo pop'); lgNull.ks.p = K([lgX, lgY, 0]);
    lgNull.ks.s = popScale(tLogo, 8, 14);
    lgNull.ks.r = keys([[tLogo, -40, 'out'], [tLogo + 14, 0]]);
    layers.push(lgNull);
    var lgShadow = shapeLayer('Logo shadow', [group([ellipse(LOGO - 6), fill(C.purple, 26)])], tLogo);
    lgShadow.parent = lgNull.ind; lgShadow.ks.p = K([0, 8, 0]); lgShadow.ef = blur(30);
    layers.push(lgShadow);
    var circ = shapeLayer('Logo circle', clone(parts.circleShapes), tLogo); circ.parent = lgNull.ind;
    var sc = LOGO / 356.647 * 100;
    circ.ks.s = K([sc, sc, 100]); circ.ks.r = K(270); circ.ks.p = K([0, 0, 0]);
    layers.push(circ);
    var pi = shapeLayer('Logo PI', clone(parts.piShapes), tLogo); pi.parent = lgNull.ind;
    pi.ks.s = K([sc, sc, 100]); pi.ks.p = K([9.5 * sc / 100, 0.3 * sc / 100, 0]);
    layers.push(pi);
    var obiDoc = textDoc('Obi by PI', 26, 'Roboto-Regular', C.muted, 26, [COL + 40, 30], [-(COL + 40) / 2, -8]); obiDoc.j = 2;
    var obiL = textLayer('Obi label', obiDoc, [lgX, lgY + LOGO / 2 + 16], tLogo + 4);
    obiL.ks.o = keys([[tLogo + 6, 0, 'out'], [tLogo + 14, 100]]);
    layers.push(obiL);

    // === Thinking dots ===
    var rx = left + COL + 28, ry = replyTop + 2;
    var dotY = ry + LH * 0.5;
    for (var d = 0; d < 3; d++) {
      var dt0 = tDots0 + d * 3, dx = rx + 12 + d * 26, dk = [];
      for (var tt = dt0; tt < tDots1; tt += 12) dk.push([tt, [dx, dotY, 0], 'out'], [tt + 5, [dx, dotY - 12, 0], 'io']);
      dk.push([Math.min(tDots1, dk[dk.length - 1][0] + 6), [dx, dotY, 0]]);
      var dot = shapeLayer('Thinking dot ' + (d + 1), [group([ellipse(16), fill(C.purple)])], tDots0 - 1, tDots1 + 4);
      dot.ks.p = posKeys(dk);
      dot.ks.o = keys([[tDots0 + d * 2, 0], [tDots0 + d * 2 + 4, 80], [tDots1, 80, 'in'], [tDots1 + 3, 0]]);
      layers.push(dot);
    }

    // === Reply text ===
    var aDoc = textDoc(t.answer, FS, 'Roboto-Regular', C.ink, LH, [TEXTW, aLay.lines * LH + 24], [0, 0]);
    var aL = textLayer('Reply', aDoc, [rx, ry], tA0 - 1);
    aL.t.a = [wordRise(tA0, tA1)];
    layers.push(aL);

    // layer order: later-pushed layers render on top in lottie when they come first in the array
    layers.reverse();
    return { layers: layers, holdEnd: tHoldEnd, still: tEnd + 4, warnings: warnings, info: { questionLines: qLay.lines, answerLines: aLay.lines, mentions: qm.names.length }, height: Math.max(convH, first ? boxH + 140 : boxH), width: BOXW };
  }

  // ---------- conversation ----------
  function build(parts, glyphs, opts) {
    var dims = SIZES[opts.size] || SIZES.square;
    W = dims[0]; H = dims[1];
    var measure = makeMeasure(glyphs);
    var smart = opts.smartQuotes !== false;
    var warnings = [], stills = [];
    var known = {}; glyphs.Regular.forEach(function (c) { known[c.ch] = 1; });
    var dropped = {};
    var san = function (s) { return Array.from(s).filter(function (ch) { if (ch === '\r' || known[ch]) return true; dropped[ch] = 1; return false; }).join('').replace(/  +/g, ' '); };
    var turns = (opts.turns || []).map(function (t) {
      return { question: san(clean(t.question, smart)), answer: san(clean(t.answer, smart)) };
    }).filter(function (t) { return t.question || t.answer; });
    if (!turns.length) turns = [{ question: '', answer: '' }];
    if (Object.keys(dropped).length) warnings.push('Removed characters the font can’t draw: ' + Object.keys(dropped).join(' '));
    var asker = san(clean(opts.asker || 'You', false)) || 'You';

    var assets = [{ id: 'avatar', w: 1536, h: 1536, u: '', p: opts.avatar || parts.avatar, e: 1 }];
    var rootLayers = [], t0 = 0, total = 0, info = { turns: turns.length, mentions: 0, questionLines: [], answerLines: [] };
    var c = [W / 2, H / 2, 0];
    var built = turns.map(function (t, k) { return buildTurn(parts, measure, t, { first: k === 0, last: k === turns.length - 1, asker: asker }); });
    // fit: grow the conversation to fill wider/taller frames (never shrink; the 'too tall' warning covers that)
    var fit = Math.min.apply(null, built.map(function (r) { return Math.min(W * 0.92 / r.width, H * 0.86 / r.height); }));
    var S = r2(Math.max(1, Math.min(1.4, fit)) * 100);
    turns.forEach(function (t, k) {
      var first = k === 0, last = k === turns.length - 1;
      var r = built[k];
      r.warnings.forEach(function (w) { warnings.push((turns.length > 1 ? 'Exchange ' + (k + 1) + ': ' : '') + w); });
      info.mentions += r.info.mentions; info.questionLines.push(r.info.questionLines); info.answerLines.push(r.info.answerLines);
      assets.push({ id: 'turn' + k, nm: 'Exchange ' + (k + 1), fr: FR, layers: r.layers });
      var outAt = t0 + r.holdEnd;
      var end = last ? outAt + 12 : outAt + 14;
      var L = { ddd: 0, ind: 10 + k, ty: 0, nm: 'Exchange ' + (k + 1), refId: 'turn' + k, sr: 1, ao: 0, w: W, h: H, ip: t0, op: end, st: t0, bm: 0,
        ks: { o: K(100), r: K(0), p: K(c), a: K(c), s: K([S, S, 100]) } };
      // in: the first fades up from the background; later ones rise into place
      var op = [], ps = [];
      if (first) op.push([0, 0, 'out'], [6, 100]);
      else { op.push([t0, 0, 'out'], [t0 + 8, 100]); ps.push([t0, [c[0], c[1] + 48, 0], 'out'], [t0 + 12, c]); }
      // out: earlier exchanges slide up and away, the last one fades to the background
      if (last) op.push([outAt, 100, 'in'], [outAt + 12, 0]);
      else { op.push([outAt, 100, 'in'], [outAt + 10, 0]); ps.push([outAt, c, 'in'], [outAt + 12, [c[0], c[1] - 260, 0]]); }
      L.ks.o = keys(op);
      if (ps.length) L.ks.p = posKeys(ps);
      stills.push({ turn: k + 1, frame: t0 + r.still });
      rootLayers.unshift(L);
      total = last ? outAt + 14 : total;
      t0 = outAt + 6;
    });
    // static background: lavender with two soft glows (kept still so GIFs stay small and loops are seamless)
    ix = 100;
    var R = Math.max(W, H) * 0.75;
    var glows = shapeLayer('Glows', [
      group([rect(W, H, 0, [W / 2, H / 2]), radialGlow(W * 0.08, H * 0.04, R, C.glowA, 0.22)], 'Glow A'),
      group([rect(W, H, 0, [W / 2, H / 2]), radialGlow(W * 0.96, H * 0.98, R, C.glowB, 0.2)], 'Glow B')]);
    glows.op = total + 10;
    var bg = layerBase('Background', 1); bg.sw = W; bg.sh = H; bg.sc = BG_HEX; bg.op = total + 10;
    var json = { v: '5.12.1', fr: FR, ip: 0, op: total, w: W, h: H, nm: opts.name || 'Obi chat', ddd: 0, assets: assets,
      fonts: { list: [{ fName: 'Roboto-Bold', fFamily: 'Roboto', fStyle: 'Bold', ascent: 75 }, { fName: 'Roboto-Regular', fFamily: 'Roboto', fStyle: 'Regular', ascent: 75 }] },
      chars: glyphs.Regular.concat(glyphs.Bold), layers: rootLayers.concat([glows, bg]), markers: [] };
    info.frames = total; info.seconds = r2(total / FR); info.width = W; info.height = H; info.scale = S / 100;
    // poster: first frame where the opening box and header are fully in — what a GIF shows first
    return { json: json, warnings: warnings, info: info, stills: stills, poster: 16, background: BG_HEX };
  }

  function parseTurns(src) {
    var blocks = [], cur = null;
    var labels = [[/^\s*(user|q|question|me|you|human|prompt)\s*:\s*/i, 'question'], [/^\s*(obi|a|answer|ai|assistant|reply|response)\s*:\s*/i, 'answer'], [/^\s*(thinking|loading|gathering|status)\s*:\s*/i, 'skip']];
    (src || '').replace(/\r\n?/g, '\n').split('\n').forEach(function (line) {
      for (var i = 0; i < labels.length; i++) { var m = line.match(labels[i][0]); if (m) { cur = { kind: labels[i][1], text: line.slice(m[0].length) }; blocks.push(cur); return; } }
      if (cur) cur.text += '\n' + line;
    });
    var turns = [], t = null;
    blocks.forEach(function (b) {
      var txt = b.text.replace(/\n{2,}/g, '\n\n').trim();
      if (b.kind === 'skip') return;
      if (b.kind === 'question') { t = { question: txt, answer: '' }; turns.push(t); return; }
      if (!t || t.answer) { t = { question: '', answer: '' }; turns.push(t); }
      t.answer = txt.replace(/\*\*/g, '');
    });
    return turns;
  }

  var api = { build: build, parseTurns: parseTurns, sizes: SIZES };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.ObiChat = api;
})(this);
